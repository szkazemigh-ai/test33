import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ContractCalculatorApp());
}

/// Some spreadsheet tools (Google Sheets among them) store the worksheet links
/// inside an .xlsx as absolute paths such as `/xl/worksheets/sheet1.xml`.
/// The `excel` package only understands the relative form, so the links are
/// rewritten before the file is handed over for decoding.
List<int> normalizeXlsx(List<int> bytes) {
  try {
    final input = ZipDecoder().decodeBytes(bytes);
    final output = Archive();
    var changed = false;
    for (final file in input) {
      if (!file.isFile) continue;
      var data = file.content as List<int>;
      if (file.name == 'xl/_rels/workbook.xml.rels') {
        final text = utf8.decode(data);
        final fixed = text
            .replaceAll('Target="/xl/', 'Target="')
            .replaceAll("Target='/xl/", "Target='");
        if (fixed != text) {
          changed = true;
          data = utf8.encode(fixed);
        }
      }
      output.addFile(ArchiveFile(file.name, data.length, data));
    }
    if (!changed) return bytes;
    return ZipEncoder().encode(output) ?? bytes;
  } catch (_) {
    return bytes;
  }
}

class IndexRecord {
  final int year;
  final int month;
  final double index;

  const IndexRecord({
    required this.year,
    required this.month,
    required this.index,
  });

  Map<String, dynamic> toJson() => {
    'year': year,
    'month': month,
    'index': index,
  };
  factory IndexRecord.fromJson(Map<String, dynamic> json) => IndexRecord(
    year: (json['year'] as num).toInt(),
    month: (json['month'] as num).toInt(),
    index: (json['index'] as num).toDouble(),
  );
}

class ContractCalculatorApp extends StatelessWidget {
  const ContractCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محاسبه‌گر قرارداد',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087A55)),
        scaffoldBackgroundColor: const Color(0xFFF6F8F7),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE0E7E3)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF087A55), width: 1.5),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _page = 0;
  final IndexDatabase _db = IndexDatabase();

  @override
  Widget build(BuildContext context) {
    final pages = [
      CalculatorPage(db: _db),
      IndexDatabasePage(db: _db),
      const SettingsPage(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[_page]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _page,
          onDestinationSelected: (i) => setState(() => _page = i),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.calculate_outlined),
              selectedIcon: Icon(Icons.calculate),
              label: 'محاسبه',
            ),
            NavigationDestination(
              icon: Icon(Icons.table_chart_outlined),
              selectedIcon: Icon(Icons.table_chart),
              label: 'شاخص‌ها',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings),
              label: 'تنظیمات',
            ),
          ],
        ),
      ),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  final IndexDatabase db;
  const CalculatorPage({super.key, required this.db});
  @override
  State<CalculatorPage> createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final contractController = TextEditingController();
  final estimateController = TextEditingController();
  final scoreController = TextEditingController();
  final dayIndexController = TextEditingController();

  int year = 1402;
  int month = 7;
  double? contractIndex;
  double? result;
  String formulaTitle = '';
  bool? passed;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadDb();
  }

  Future<void> _loadDb() async {
    await widget.db.load();
    _updateContractIndex();
    setState(() => loading = false);
  }

  void _updateContractIndex() {
    contractIndex = widget.db.find(year, month);
  }

  @override
  void dispose() {
    contractController.dispose();
    estimateController.dispose();
    scoreController.dispose();
    dayIndexController.dispose();
    super.dispose();
  }

  double? _number(String value) {
    final normalized = value
        .replaceAll(',', '')
        .replaceAll('٬', '')
        .replaceAll('٫', '.')
        .replaceAllMapped(
          RegExp(r'[۰-۹]'),
          (m) => String.fromCharCode(
            m.group(0)!.codeUnitAt(0) - '۰'.codeUnitAt(0) + '0'.codeUnitAt(0),
          ),
        )
        .replaceAllMapped(
          RegExp(r'[٠-٩]'),
          (m) => String.fromCharCode(
            m.group(0)!.codeUnitAt(0) - '٠'.codeUnitAt(0) + '0'.codeUnitAt(0),
          ),
        );
    return double.tryParse(normalized);
  }

  void _calculate() {
    final contract = _number(contractController.text);
    final estimate = _number(estimateController.text);
    final score = _number(scoreController.text);
    final dayIndex = _number(dayIndexController.text);

    if (contract == null ||
        estimate == null ||
        estimate == 0 ||
        score == null ||
        dayIndex == null ||
        dayIndex == 0) {
      _showMessage('لطفاً همه اطلاعات عددی را به‌درستی وارد کنید.');
      return;
    }
    if (contractIndex == null || contractIndex == 0) {
      _showMessage('شاخص قرارداد برای این ماه در دیتابیس Excel پیدا نشد.');
      return;
    }

    final base = (contract / estimate) * score * (dayIndex / contractIndex!);
    final isOld = year < 1400 || (year == 1400 && month < 12);
    final finalResult = isOld ? base * (608 / 174) : base;
    final threshold = score * 0.40;

    setState(() {
      result = finalResult;
      passed = finalResult >= threshold;
      formulaTitle = isOld
          ? 'فرمول قراردادهای قبل از اسفند ۱۴۰۰'
          : 'فرمول قراردادهای اسفند ۱۴۰۰ و بعد از آن';
    });
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return CustomScrollView(
      slivers: [
        const SliverAppBar(
          title: Text('محاسبه قرارداد'),
          centerTitle: true,
          pinned: true,
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              _sectionTitle('تاریخ قرارداد'),
              _datePicker(context),
              const SizedBox(height: 14),
              _sectionTitle('اطلاعات مالی'),
              _moneyField(
                contractController,
                'مبلغ قرارداد (ریال)',
                Icons.payments_outlined,
              ),
              const SizedBox(height: 12),
              _moneyField(
                estimateController,
                'مبلغ برآورد (ریال)',
                Icons.account_balance_wallet_outlined,
              ),
              const SizedBox(height: 14),
              _sectionTitle('امتیاز و شاخص‌ها'),
              _numberField(scoreController, 'امتیاز معیار', Icons.star_outline),
              const SizedBox(height: 12),
              _numberField(
                dayIndexController,
                'شاخص روز',
                Icons.insights_outlined,
              ),
              const SizedBox(height: 10),
              _indexCard(),
              const SizedBox(height: 18),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: _calculate,
                  icon: const Icon(Icons.calculate),
                  label: const Text(
                    'محاسبه',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              if (result != null) ...[
                const SizedBox(height: 18),
                _resultCard(),
              ],
            ]),
          ),
        ),
      ],
    );
  }

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
    ),
  );

  Widget _datePicker(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () async {
        final selected = await showModalBottomSheet<List<int>>(
          context: context,
          isScrollControlled: true,
          builder: (_) =>
              MonthYearPicker(initialYear: year, initialMonth: month),
        );
        if (selected != null) {
          setState(() {
            year = selected[0];
            month = selected[1];
            _updateContractIndex();
            result = null;
          });
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE0E7E3)),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_month, color: Color(0xFF087A55)),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                '${monthName(month)} $year',
                style: const TextStyle(fontSize: 16),
              ),
            ),
            const Icon(Icons.expand_more),
          ],
        ),
      ),
    );
  }

  Widget _moneyField(TextEditingController c, String label, IconData icon) =>
      TextField(
        controller: c,
        keyboardType: TextInputType.number,
        textDirection: TextDirection.ltr,
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      );
  Widget _numberField(TextEditingController c, String label, IconData icon) =>
      TextField(
        controller: c,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        textDirection: TextDirection.ltr,
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
      );

  Widget _indexCard() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFFEAF6F1),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Row(
      children: [
        const Icon(Icons.auto_graph, color: Color(0xFF087A55)),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'شاخص قرارداد',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                contractIndex == null
                    ? 'در دیتابیس پیدا نشد'
                    : formatNumber(contractIndex!),
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _resultCard() {
    final green = passed == true;
    final bg = green ? const Color(0xFFDDF7E9) : const Color(0xFFFFE3E3);
    final fg = green ? const Color(0xFF087A55) : const Color(0xFFB42318);
    final score = _number(scoreController.text) ?? 0;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Icon(green ? Icons.check_circle : Icons.cancel, color: fg, size: 42),
          const SizedBox(height: 8),
          Text(
            'نتیجه نهایی',
            style: TextStyle(color: fg, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            formatNumber(result!),
            style: TextStyle(
              color: fg,
              fontSize: 38,
              fontWeight: FontWeight.w900,
            ),
          ),
          Text('از امتیاز معیار $score', style: TextStyle(color: fg)),
          const SizedBox(height: 12),
          Text(
            green
                ? 'نتیجه در محدوده مجاز است.'
                : 'نتیجه کمتر از ۴۰٪ امتیاز معیار است.',
            style: TextStyle(color: fg, fontWeight: FontWeight.bold),
          ),
          const Divider(height: 24),
          Text(formulaTitle, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class MonthYearPicker extends StatefulWidget {
  final int initialYear;
  final int initialMonth;
  const MonthYearPicker({
    super.key,
    required this.initialYear,
    required this.initialMonth,
  });
  @override
  State<MonthYearPicker> createState() => _MonthYearPickerState();
}

class _MonthYearPickerState extends State<MonthYearPicker> {
  late int selectedYear;
  late int selectedMonth;
  final years = List<int>.generate(151, (i) => 1350 + i);
  @override
  void initState() {
    super.initState();
    selectedYear = widget.initialYear;
    selectedMonth = widget.initialMonth;
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'انتخاب ماه و سال قرارداد',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 220,
            child: Row(
              children: [
                Expanded(
                  child: ListWheelScrollView.useDelegate(
                    itemExtent: 48,
                    perspective: 0.002,
                    diameterRatio: 1.4,
                    onSelectedItemChanged: (i) =>
                        setState(() => selectedYear = years[i]),
                    childDelegate: ListWheelChildBuilderDelegate(
                      builder: (_, i) => i < years.length
                          ? Center(
                              child: Text(
                                '${years[i]}',
                                style: TextStyle(
                                  fontSize: years[i] == selectedYear ? 20 : 16,
                                  fontWeight: years[i] == selectedYear
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                            )
                          : null,
                      childCount: years.length,
                    ),
                    controller: FixedExtentScrollController(
                      initialItem: years
                          .indexOf(selectedYear)
                          .clamp(0, years.length - 1),
                    ),
                  ),
                ),
                Expanded(
                  child: ListWheelScrollView.useDelegate(
                    itemExtent: 48,
                    perspective: 0.002,
                    diameterRatio: 1.4,
                    onSelectedItemChanged: (i) =>
                        setState(() => selectedMonth = i + 1),
                    childDelegate: ListWheelChildBuilderDelegate(
                      builder: (_, i) => i < 12
                          ? Center(
                              child: Text(
                                monthName(i + 1),
                                style: TextStyle(
                                  fontSize: i + 1 == selectedMonth ? 18 : 15,
                                  fontWeight: i + 1 == selectedMonth
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                            )
                          : null,
                      childCount: 12,
                    ),
                    controller: FixedExtentScrollController(
                      initialItem: selectedMonth - 1,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: () =>
                  Navigator.pop(context, [selectedYear, selectedMonth]),
              child: const Text('تأیید'),
            ),
          ),
        ],
      ),
    ),
  );
}

class IndexDatabase {
  List<IndexRecord> records = [];
  bool loaded = false;

  Future<void> load() async {
    if (loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('index_records');
    if (raw != null) {
      records = (jsonDecode(raw) as List)
          .map((e) => IndexRecord.fromJson(e))
          .toList();
    }
    loaded = true;
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'index_records',
      jsonEncode(records.map((e) => e.toJson()).toList()),
    );
  }

  double? find(int year, int month) {
    for (final r in records) {
      if (r.year == year && r.month == month) return r.index;
    }
    return null;
  }
}

class IndexDatabasePage extends StatefulWidget {
  final IndexDatabase db;
  const IndexDatabasePage({super.key, required this.db});
  @override
  State<IndexDatabasePage> createState() => _IndexDatabasePageState();
}

class _IndexDatabasePageState extends State<IndexDatabasePage> {
  bool loading = true;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await widget.db.load();
    setState(() => loading = false);
  }

  Future<void> _importExcel() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
      withData: true,
    );
    if (result == null) return;
    try {
      final bytes =
          result.files.single.bytes ??
          await File(result.files.single.path!).readAsBytes();
      final book = Excel.decodeBytes(normalizeXlsx(bytes));
      final sheet = book.tables.values.first;
      final parsed = <IndexRecord>[];
      for (var r = 0; r < sheet.maxRows; r++) {
        final row = sheet.row(r);
        if (row.length < 3) continue;
        final year = parseYear(row[0]?.value);
        final month = parseMonth(row[1]?.value);
        final index = parseDouble(row[2]?.value);
        if (year != null && month != null && index != null)
          parsed.add(IndexRecord(year: year, month: month, index: index));
      }
      if (parsed.isEmpty) throw Exception('ردیف معتبر پیدا نشد');
      parsed.sort(
        (a, b) => a.year != b.year
            ? a.year.compareTo(b.year)
            : a.month.compareTo(b.month),
      );
      setState(() => widget.db.records = parsed);
      await widget.db.save();
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${parsed.length} ردیف وارد شد.')),
        );
    } catch (e) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'فایل Excel قابل خواندن نبود. ساختار ستون‌ها را بررسی کنید.',
            ),
          ),
        );
    }
  }

  Future<void> _exportExcel() async {
    final book = Excel.createExcel();
    book.rename('Sheet1', 'شاخص‌ها');
    final sheet = book['شاخص‌ها'];
    sheet.appendRow([
      TextCellValue('سال'),
      TextCellValue('ماه'),
      TextCellValue('شاخص'),
    ]);
    for (final r in widget.db.records)
      sheet.appendRow([
        IntCellValue(r.year),
        IntCellValue(r.month),
        DoubleCellValue(r.index),
      ]);
    final bytes = book.encode();
    if (bytes == null) return;
    final path = await FilePicker.platform.saveFile(
      dialogTitle: 'ذخیره فایل شاخص‌ها',
      fileName: 'شاخص‌ها.xlsx',
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
      bytes: bytes,
    );
    if (path != null && !Platform.isAndroid && !Platform.isIOS)
      await File(path).writeAsBytes(bytes);
    if (mounted)
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('فایل Excel آماده شد.')));
  }

  Future<void> _edit(int i) async {
    final r = widget.db.records[i];
    final c = TextEditingController(text: r.index.toString());
    final value = await showDialog<double>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${monthName(r.month)} ${r.year}'),
        content: TextField(
          controller: c,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'شاخص'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('لغو'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              double.tryParse(c.text.replaceAll(',', '')),
            ),
            child: const Text('ذخیره'),
          ),
        ],
      ),
    );
    if (value != null) {
      setState(
        () => widget.db.records[i] = IndexRecord(
          year: r.year,
          month: r.month,
          index: value,
        ),
      );
      await widget.db.save();
    }
  }

  Future<void> _add() async {
    final yearController = TextEditingController(text: '1403');
    final indexController = TextEditingController();
    int selectedMonth = 1;
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('افزودن شاخص جدید'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: yearController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'سال'),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFE0E7E3)),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: DropdownButton<int>(
                  value: selectedMonth,
                  isExpanded: true,
                  underline: const SizedBox.shrink(),
                  items: List.generate(
                    12,
                    (i) => DropdownMenuItem<int>(
                      value: i + 1,
                      child: Text(monthName(i + 1)),
                    ),
                  ),
                  onChanged: (v) =>
                      setDialogState(() => selectedMonth = v ?? selectedMonth),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: indexController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(labelText: 'شاخص'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('لغو'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('ذخیره'),
            ),
          ],
        ),
      ),
    );
    if (saved != true) return;
    final year = parseYear(yearController.text);
    final index = parseDouble(indexController.text);
    if (year == null || index == null) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('سال و شاخص را درست وارد کنید.')),
        );
      return;
    }
    setState(() {
      widget.db.records.removeWhere(
        (r) => r.year == year && r.month == selectedMonth,
      );
      widget.db.records.add(
        IndexRecord(year: year, month: selectedMonth, index: index),
      );
      widget.db.records.sort(
        (a, b) => a.year != b.year
            ? a.year.compareTo(b.year)
            : a.month.compareTo(b.month),
      );
    });
    await widget.db.save();
    if (mounted)
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('شاخص افزوده شد.')));
  }

  Future<void> _delete(int i) async {
    final r = widget.db.records[i];
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف شاخص'),
        content: Text('شاخص ${monthName(r.month)} ${r.year} حذف شود؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('لغو'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => widget.db.records.removeAt(i));
      await widget.db.save();
    }
  }

  Future<void> _deleteAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('پاک کردن همه'),
        content: const Text('همه شاخص‌ها حذف شوند؟ این کار قابل بازگشت نیست.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('لغو'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('پاک کردن'),
          ),
        ],
      ),
    );
    if (ok == true) {
      setState(() => widget.db.records.clear());
      await widget.db.save();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return CustomScrollView(
      slivers: [
        const SliverAppBar(title: Text('مدیریت دیتابیس شاخص‌ها'), pinned: true),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Column(
                  children: [
                    const Icon(
                      Icons.file_copy_outlined,
                      size: 42,
                      color: Color(0xFF087A55),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'تعداد رکوردها: ${widget.db.records.length}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _importExcel,
                            icon: const Icon(Icons.upload_file),
                            label: const Text('ورود Excel'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: widget.db.records.isEmpty
                                ? null
                                : _exportExcel,
                            icon: const Icon(Icons.download),
                            label: const Text('خروجی Excel'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton.icon(
                            onPressed: _add,
                            icon: const Icon(Icons.add),
                            label: const Text('افزودن شاخص'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: widget.db.records.isEmpty
                                ? null
                                : _deleteAll,
                            icon: const Icon(Icons.delete_sweep_outlined),
                            label: const Text('پاک کردن همه'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFFB42318),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              if (widget.db.records.isEmpty)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Text('هنوز دیتابیس شاخص وارد نشده است.'),
                  ),
                )
              else
                ...widget.db.records.asMap().entries.map((entry) {
                  final i = entry.key;
                  final r = entry.value;
                  return Card(
                    child: ListTile(
                      title: Text('${monthName(r.month)} ${r.year}'),
                      subtitle: Text('شاخص: ${formatNumber(r.index)}'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () => _edit(i),
                          ),
                          IconButton(
                            icon: const Icon(
                              Icons.delete_outline,
                              color: Color(0xFFB42318),
                            ),
                            onPressed: () => _delete(i),
                          ),
                        ],
                      ),
                    ),
                  );
                }),
            ]),
          ),
        ),
      ],
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const SizedBox(height: 12),
      const Text(
        'تنظیمات',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 20),
      Card(
        child: ListTile(
          leading: const Icon(Icons.info_outline),
          title: const Text('درباره برنامه'),
          subtitle: const Text('محاسبه‌گر قرارداد - نسخه ۱.۰'),
        ),
      ),
      Card(
        child: ListTile(
          leading: const Icon(Icons.rule),
          title: const Text('قاعده محاسبه'),
          subtitle: const Text(
            'مرز ۴۰٪ امتیاز معیار برای رنگ نتیجه استفاده می‌شود.',
          ),
        ),
      ),
    ],
  );
}

String monthName(int month) => const [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
][month - 1];
String formatNumber(double n) =>
    n % 1 == 0 ? n.toStringAsFixed(0) : n.toStringAsFixed(2);

int? parseYear(dynamic v) => parseDouble(v)?.round();
int? parseMonth(dynamic v) {
  if (v == null) return null;
  final s = v.toString().trim();
  final n = parseDouble(v)?.round();
  if (n != null && n >= 1 && n <= 12) return n;
  const names = {
    'فروردین': 1,
    'اردیبهشت': 2,
    'خرداد': 3,
    'تیر': 4,
    'مرداد': 5,
    'شهریور': 6,
    'مهر': 7,
    'آبان': 8,
    'آذر': 9,
    'دی': 10,
    'بهمن': 11,
    'اسفند': 12,
  };
  return names[s];
}

double? parseDouble(dynamic v) {
  if (v == null) return null;
  var s = v
      .toString()
      .trim()
      .replaceAll(',', '')
      .replaceAll('٬', '')
      .replaceAll('٫', '.');
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  for (var i = 0; i < 10; i++) {
    s = s.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return double.tryParse(s);
}
