# راهنمای ساخت فایل نصبی (APK) در GitHub

این روش لازم به نصب هیچ برنامه‌ای روی کامپیوتر نیست. فقط یک حساب رایگان GitHub کافی است.
حدود ۱۰ تا ۱۵ دقیقه طول می‌کشد.

## قدم ۱ — ساخت حساب GitHub
1. به آدرس https://github.com/signup بروید.
2. ایمیل، رمز عبور و نام کاربری بگذارید و حساب را بسازید.
3. اگر ایمیل تأیید خواست، لینک را بزنید.

## قدم ۲ — ساخت یک فضای خالی (Repository)
1. وارد GitHub شوید.
2. بالای صفحه روی علامت **+** کلیک کنید و **New repository** را بزنید.
3. در قسمت **Repository name** بنویسید: `mahaseb-gharardad`
4. حالت **Public** را انتخاب کنید (رایگان است و برای این کار لازم است).
5. تیک **Add a README file** را **نزنید** (باید فضای خالی بماند).
6. دکمه **Create repository** را بزنید.

## قدم ۳ — آپلود فایل‌های برنامه
1. فایل فشرده را از این گفتگو دانلود و با راست‌کلیک **Extract All** باز کنید تا پوشه `mahaseb_gharardad` ساخته شود.
2. در صفحه‌ی همان فضای خالی در GitHub، روی **uploading an existing file** کلیک کنید.
3. محتویات داخل پوشه `mahaseb_gharardad` را با ماوس بگیرید و در صفحه GitHub رها کنید
   (فایل‌های `pubspec.yaml`، `README.md`، `APK_GUIDE.md`، `build_apk.bat`، `.gitignore` و پوشه‌های `lib` و `assets`).
4. پایین صفحه دکمه **Commit changes** را بزنید.

> اگر پوشه‌ی مخفی `.github` دیده نشد، نگران نباشید — در قدم ۴ همان فایل را دستی می‌سازیم.

## قدم ۴ — ساخت فایل دستور ساخت APK
1. در همان صفحه GitHub، روی **Add file** و بعد **Create new file** کلیک کنید.
2. در کادر بالای صفحه، مسیر فایل را دقیقاً این‌طور تایپ کنید:
   `.github/workflows/android.yml`
   (وقتی `/` را تایپ کنید، خودش پوشه می‌سازد.)
3. محتوای زیر را در کادر بزرگ متن کپی کنید:

```yaml
name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Download code
        uses: actions/checkout@v4

      - name: Install Flutter
        uses: subosito/flutter-action@v2
        with:
          channel: stable
          cache: true

      - name: Generate Android project files
        run: |
          cp lib/main.dart /tmp/main.bak
          cp pubspec.yaml /tmp/pubspec.bak
          flutter create . --platforms=android --org ir.mahaseb --project-name mahaseb_gharardad
          cp /tmp/main.bak lib/main.dart
          cp /tmp/pubspec.bak pubspec.yaml
          rm -f analysis_options.yaml

      - name: Get packages
        run: flutter pub get

      - name: Build APK
        run: flutter build apk --release

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: mahaseb-gharardad-apk
          path: build/app/outputs/flutter-apk/app-release.apk
          if-no-files-found: error
```

4. پایین صفحه **Commit changes** را بزنید.

## قدم ۵ — گرفتن فایل نصبی
1. بالای صفحه تب **Actions** را بزنید.
2. روی جدیدترین اجرا کلیک کنید و صبر کنید تا سبز و تیک‌دار شود (حدود ۱۰ دقیقه).
3. در پایین همان صفحه، در قسمت **Artifacts** روی `mahaseb-gharardad-apk` کلیک کنید.
4. فایل `app-release.apk` را دانلود کنید.
5. فایل را به گوشی منتقل و روی آن نصب کنید (اگر پیام هشدار آمد، گزینه‌ی «اجرا از این منبع» یا Allow from this source را بزنید).

## اگر خطا دیدم چه کار کنم؟
در تب Actions روی اجرای قرمز کلیک کنید، روی مرحله‌ی قرمز (مثلاً Build APK) بزنید،
متن خطا را کپی کنید و در همین گفتگو بفرستید تا کد را اصلاح کنم.

## راه دوم (اگر GitHub اذیت کرد)
Flutter و Android Studio را روی ویندوز نصب کنید، پوشه برنامه را باز کنید و
روی فایل `build_apk.bat` دوبار کلیک کنید. فایل `mahaseb-gharardad.apk` ساخته می‌شود.
