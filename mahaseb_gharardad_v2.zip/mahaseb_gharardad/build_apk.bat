@echo off
setlocal
if not exist android (
  copy /y lib\main.dart "%TEMP%\main.bak" >nul
  copy /y pubspec.yaml "%TEMP%\pubspec.bak" >nul
  call flutter create . --platforms=android --org ir.mahaseb --project-name mahaseb_gharardad
  copy /y "%TEMP%\main.bak" lib\main.dart >nul
  copy /y "%TEMP%\pubspec.bak" pubspec.yaml >nul
  del analysis_options.yaml >nul 2>&1
)
call flutter pub get
call flutter build apk --release
if exist build\app\outputs\flutter-apk\app-release.apk (
  copy /y build\app\outputs\flutter-apk\app-release.apk mahaseb-gharardad.apk >nul
  echo.
  echo APK READY: mahaseb-gharardad.apk
) else (
  echo.
  echo BUILD FAILED - send the error text to Lovable.
)
pause
